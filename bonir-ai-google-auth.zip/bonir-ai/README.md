# Bonir AI — full-stack starter

Bonir AI is an original AI creation platform starter with a responsive Next.js frontend, NestJS API, Prisma/PostgreSQL schema, Redis/BullMQ infrastructure, admin-facing routes, and provider/payment adapter boundaries.

## Important truth about integrations
This repository does **not** pretend to generate media or accept payments without real provider credentials and verified adapters. Until configured, generation and payment actions return an explicit `503` response. No fake outputs, fake payments, or secret keys are included.

## Stack
- Node.js 22 LTS (or another supported LTS validated against the selected dependencies)
- Next.js App Router + TypeScript + Tailwind
- NestJS + class-validator
- PostgreSQL + Prisma
- Redis + BullMQ (infrastructure is included; jobs are not queued until a provider adapter is implemented)
- Docker Compose for local PostgreSQL and Redis

## Quick start (Windows PowerShell)
1. Install Node.js LTS, Git, and Docker Desktop.
2. Copy `.env.example` to `.env` in the repository root.
3. Set a strong local `DB_PASSWORD` in `.env`.
4. Start infrastructure:
   ```powershell
   docker compose up -d
   ```
5. Configure API environment:
   ```powershell
   Copy-Item apps/api/.env.example apps/api/.env
   ```
   Edit `apps/api/.env` and set `DATABASE_URL` using the same password as root `.env`.
6. Install and migrate API:
   ```powershell
   cd apps/api
   npm install
   npx prisma generate
   npx prisma migrate dev --name init
   npm run start:dev
   ```
7. In another terminal, install and start frontend:
   ```powershell
   cd apps/web
   npm install
   Copy-Item .env.example .env.local
   npm run dev
   ```
8. Open `http://localhost:3000`. API base defaults to `http://localhost:4000/api/v1`.

## Monorepo layout
- `apps/web`: responsive public pages, workspace, account, history, pricing, login/register UI, admin shell.
- `apps/api`: API, config validation, health, Prisma, models, generation boundary, credit balance read endpoint.
- `apps/api/prisma/schema.prisma`: users, sessions, providers, models, generation jobs, assets, credit ledger, payment orders/events, plans, subscriptions, audit log.
- `infra`: reverse-proxy example and production notes.
- `docs`: architecture, security, integration checklist, VPS deployment notes.

## API endpoints
- `GET /api/v1/health` — database health.
- `GET /api/v1/models` — enabled models backed by enabled providers only.
- `POST /api/v1/generations` — explicit `503` until a verified provider adapter is implemented.
- `GET /api/v1/credits/balance` — explicit `401` until real authentication is implemented; never returns a fake balance.
- `POST /api/v1/payments/checkout` — explicit `503` until a real payment adapter is implemented.

## Not yet production-ready
This is a broad, working development foundation, not a launched commercial service. Before taking money or exposing it publicly, implement and test:
- authentication (password reset, email verification, secure sessions, rate limits, CSRF strategy)
- verified provider adapters and provider-specific moderation/error mapping
- atomic credit reservations/capture/release and reconciliation
- payment checkout + signed webhook verification + idempotency
- object storage with private access and signed downloads
- admin authorization (server-enforced permissions), audit events, support workflows
- monitoring, backups, abuse controls, privacy/terms, and security review

Never put AI provider or payment secrets in frontend environment variables or commit them to Git.


## Authentication setup (email/password + Google)

Email/password registration and sign-in use the NestJS API and PostgreSQL sessions. Google sign-in uses OAuth 2.0 and requires real credentials from Google Cloud Console; it is intentionally unavailable until configured. See `docs/INTEGRATIONS.md` for callback URI, environment variables, schema update, and secure account-linking instructions.

For local development, copy `apps/api/.env.example` to `apps/api/.env` and `apps/web/.env.example` to `apps/web/.env.local`. Set a local `DATABASE_URL`, `API_URL=http://localhost:4000`, `WEB_URL=http://localhost:3000`, and a random `AUTH_SECRET` of at least 32 characters. Apply the schema from `apps/api` with `npx prisma db push` and `npx prisma generate`. Configure Google credentials before testing Google sign-in.
