# Architecture

## Services
- `apps/web`: Next.js UI and server-rendered model catalogue.
- `apps/api`: NestJS API boundary; never expose provider secrets to web clients.
- PostgreSQL: persistent business state.
- Redis: planned job queue/cache infrastructure.
- Object storage: not configured yet; required for media at scale.

## Generation lifecycle (target)
1. Authenticated user submits validated model ID, prompt, parameters, and idempotency key.
2. API checks user status, model/provider enabled status, moderation, usage limits, and current price.
3. In one database transaction, reserve credits and create a generation job.
4. Worker dispatches to a verified provider adapter and persists external job ID.
5. Poll/webhook worker reconciles status and validates provider output.
6. Store output in private object storage and create asset records.
7. Capture actual cost or release unused reservation exactly once.
8. Audit relevant administrative and financial operations.

No lifecycle steps above are implemented merely by this architecture document. The current generation endpoint deliberately returns 503 until an adapter exists.
