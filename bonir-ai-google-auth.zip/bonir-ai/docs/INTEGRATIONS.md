# Provider and payment integration checklist

## AI provider
For each provider, record:
- official API documentation URL and account eligibility
- supported model IDs and modalities
- synchronous/asynchronous behavior, status polling, webhook behavior
- input/output limits, supported formats, region restrictions
- per-generation pricing and cancellation/refund semantics
- content moderation and retention terms
- timeout/retry policy and rate limits

Implement a typed adapter behind a provider interface. Do not assume different providers share the same request schema. Add contract tests using provider test mode or non-billable validation endpoints where available. Keep provider disabled until verified.

## Payments
- Select provider based on the business's legal entity and supported country.
- Implement hosted checkout or tokenized payment flow.
- Verify webhook signature using raw request body and secret.
- Store provider event ID with a unique constraint and make handlers idempotent.
- Never trust a browser redirect as proof of payment.
- Credit only after server-verified payment success.
- Implement refunds, disputes, reconciliation, and audit logs before launch.


## Google sign-in and account linking

The API implements Google OAuth 2.0 authorization-code flow with state validation, a verified Google email requirement, opaque database-backed sessions, and HttpOnly cookies. Passwords are hashed with Node.js scrypt. Google accounts are stored separately in `OAuthAccount`; an email match alone never silently links an existing account.

1. Create an OAuth 2.0 Web application client in Google Cloud Console.
2. Add the exact authorized redirect URI `http://localhost:4000/api/v1/auth/google/callback` for local development. In production use `https://YOUR_API_HOST/api/v1/auth/google/callback`.
3. Copy `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `AUTH_SECRET` (at least 32 random characters), `API_URL`, and `WEB_URL` into `apps/api/.env`. `API_URL` is the externally reachable API origin; `WEB_URL` is the web origin.
4. Set `NEXT_PUBLIC_API_URL` in `apps/web/.env.local` to the public API base URL including `/api/v1`.
5. Apply the schema: from `apps/api`, run `npx prisma db push` and then `npx prisma generate`. Back up any existing database before schema changes.
6. Start the API and web app. Google sign-in creates a new account only if the verified email is not already registered. If the email already belongs to a password account, sign in with that password, open `/app/security`, confirm the password, then connect Google. The Google email must match the Bonir AI account email.

Before public production launch, serve both apps over HTTPS, set `NODE_ENV=production`, use a unique secret from a secrets manager, configure database backups and a persistent shared rate limiter at the reverse proxy/API gateway, verify OAuth consent-screen publishing requirements, and test callback URLs on the production domain. Never commit real credentials to Git.
