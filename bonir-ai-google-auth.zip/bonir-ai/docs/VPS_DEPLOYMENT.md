# VPS deployment plan (not yet deployed)

1. Choose a VPS region based on customer location, provider availability, privacy needs, and budget.
2. Create a non-root deployment user; configure SSH keys, firewall, security updates, and disable password SSH where practical.
3. Deploy pinned Docker images or build artifacts in CI; never copy local `.env` into Git.
4. Put Nginx or Caddy in front of the web and API services; enable HTTPS and security headers.
5. Keep PostgreSQL and Redis on a private network, with strong credentials and no public ports.
6. Use managed or separately backed-up PostgreSQL; encrypt backups and test restoration.
7. Configure object storage for media; do not store large generation files on the app container filesystem.
8. Add process health checks, logs, metrics, uptime checks, and alerts.
9. Configure provider/payment secrets through deployment secrets, not frontend variables.
10. Run migration and smoke tests before switching production traffic.
11. Complete the security checklist before enabling registration, paid generations, or checkout.
