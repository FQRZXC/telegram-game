# Security checklist before public launch

- [ ] Implement secure authentication, password hashing (Argon2id or equivalent), email verification, password reset, session rotation and revocation.
- [ ] Add server-side authorization guards to every private and admin endpoint.
- [ ] Set secure, HttpOnly, SameSite cookies and a deliberate CSRF strategy.
- [ ] Rate-limit login, registration, generation, upload, checkout, and webhook endpoints.
- [ ] Validate request DTOs and limit prompt length, file size, MIME type, and upload count.
- [ ] Keep AI/payment keys server-side; rotate keys and use a secret manager for production.
- [ ] Verify payment webhook signatures against raw request bytes and deduplicate event IDs.
- [ ] Use database transactions, unique idempotency keys, and reconciliation for all money/credit operations.
- [ ] Keep uploaded and generated files private; use signed URLs and ownership checks.
- [ ] Add content moderation and abuse reporting consistent with provider terms and applicable law.
- [ ] Configure HTTPS, restrictive CORS, CSP, secure headers, database network rules, and firewall.
- [ ] Configure encrypted backups and test restores.
- [ ] Add structured logs with secrets and personal data redacted, error monitoring, and alerts.
- [ ] Run dependency scanning, tests, threat modeling, and an independent security review.


## Implemented authentication controls

- Passwords are stored as salted Node.js scrypt hashes; raw passwords are not stored.
- Sessions use cryptographically random opaque tokens. Only SHA-256 token hashes are stored in PostgreSQL; browser cookies are HttpOnly and SameSite=Lax, and Secure in production.
- Google OAuth uses a signed, short-lived state cookie and requires a verified Google email from Google's userinfo endpoint.
- Existing email accounts are not automatically linked based only on matching email. Linking requires an active session, password re-confirmation, and a matching verified Google email.
- The OAuth account table has unique constraints on provider identity and provider/user pair to prevent duplicate links.

These controls do not replace production hardening. Add rate limiting at the reverse proxy/API gateway, serve over HTTPS, use a strong random `AUTH_SECRET`, monitor authentication failures, test backup/restore, and review the complete application before launch. Email verification, password reset, MFA, and account recovery are not implemented in this starter.
