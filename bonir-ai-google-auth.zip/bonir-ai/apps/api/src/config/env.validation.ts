import { plainToInstance } from 'class-transformer';
import {
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  IsUrl,
  Max,
  Min,
  validateSync,
} from 'class-validator';

class EnvironmentVariables {
  @IsIn(['development', 'test', 'production'])
  NODE_ENV!: string;

  @IsInt()
  @Min(1)
  @Max(65535)
  PORT = 4000;

  @IsString()
  DATABASE_URL!: string;

  @IsUrl({ require_tld: false })
  REDIS_URL!: string;

  @IsUrl({ require_tld: false })
  WEB_URL = 'http://localhost:3000';

  @IsOptional() @IsUrl({ require_tld: false }) API_URL?: string;

  @IsOptional() @IsString() GOOGLE_CLIENT_ID?: string;
  @IsOptional() @IsString() GOOGLE_CLIENT_SECRET?: string;
  @IsOptional() @IsString() AUTH_SECRET?: string;

  @IsOptional()
  @IsString()
  AI_PROVIDER?: string;

  @IsOptional()
  @IsUrl({ require_tld: false })
  AI_API_BASE_URL?: string;

  @IsOptional()
  @IsString()
  AI_API_KEY?: string;
}

export function validateEnvironment(config: Record<string, unknown>) {
  const values = plainToInstance(EnvironmentVariables, config, {
    enableImplicitConversion: true,
  });
  const errors = validateSync(values, { skipMissingProperties: false });

  if (errors.length > 0) {
    throw new Error(
      `Invalid environment configuration: ${errors.map((e) => e.property).join(', ')}`,
    );
  }

  const googleFields = [values.GOOGLE_CLIENT_ID, values.GOOGLE_CLIENT_SECRET];
  if (googleFields.some(Boolean) && !googleFields.every(Boolean)) {
    throw new Error('GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET must be configured together');
  }
  if (values.NODE_ENV === 'production' && (!values.AUTH_SECRET || values.AUTH_SECRET.length < 32)) {
    throw new Error('AUTH_SECRET must contain at least 32 characters in production');
  }
  const aiFields = [values.AI_PROVIDER, values.AI_API_BASE_URL, values.AI_API_KEY];
  if (aiFields.some(Boolean) && !aiFields.every(Boolean)) {
    throw new Error(
      'AI_PROVIDER, AI_API_BASE_URL and AI_API_KEY must be configured together',
    );
  }

  return values;
}
