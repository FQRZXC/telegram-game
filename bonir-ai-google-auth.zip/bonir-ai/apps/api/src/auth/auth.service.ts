import { Injectable, UnauthorizedException, ConflictException, BadRequestException, ForbiddenException, ServiceUnavailableException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import { createHash, createHmac, randomBytes, scrypt as scryptCallback, timingSafeEqual } from 'crypto';
import { promisify } from 'util';

const scrypt = promisify(scryptCallback) as (password: string, salt: string, keylen: number) => Promise<Buffer>;
const SESSION_COOKIE = 'bonir_session';
const STATE_COOKIE = 'bonir_oauth_state';
const LINK_COOKIE = 'bonir_link_intent';
const SESSION_DAYS = 30;

type GoogleProfile = { sub: string; email: string; email_verified: boolean; name?: string };

@Injectable()
export class AuthService {
  constructor(private readonly prisma: PrismaService, private readonly config: ConfigService) {}

  private get apiUrl() { return (this.config.get<string>('API_URL') || `http://localhost:${this.config.get<number>('PORT', 4000)}`).replace(/\/$/, ''); }
  private get webUrl() { return (this.config.get<string>('WEB_URL') || 'http://localhost:3000').replace(/\/$/, ''); }
  private get production() { return this.config.get<string>('NODE_ENV') === 'production'; }
  private get authSecret() {
    const secret = this.config.get<string>('AUTH_SECRET');
    if (!secret || secret.length < 32) {
      if (this.production) throw new ServiceUnavailableException('Authentication is not configured securely');
      return 'local-development-only-secret-change-before-deploy-32chars';
    }
    return secret;
  }
  cookieOptions(maxAge?: number) {
    return { httpOnly: true, secure: this.production, sameSite: 'lax' as const, path: '/', ...(maxAge ? { maxAge } : {}) };
  }
  hash(value: string) { return createHash('sha256').update(value).digest('hex'); }

  private async passwordHash(password: string) {
    const salt = randomBytes(16).toString('hex');
    const key = await scrypt(password, salt, 64);
    return `scrypt$${salt}$${key.toString('hex')}`;
  }
  private async verifyPassword(password: string, encoded?: string | null) {
    if (!encoded) return false;
    const [algorithm, salt, hash] = encoded.split('$');
    if (algorithm !== 'scrypt' || !salt || !hash) return false;
    const expected = Buffer.from(hash, 'hex');
    const actual = await scrypt(password, salt, expected.length);
    return expected.length === actual.length && timingSafeEqual(expected, actual);
  }
  private parseCookies(raw?: string): Record<string, string> {
    const out: Record<string, string> = {};
    for (const item of (raw || '').split(';')) {
      const idx = item.indexOf('=');
      if (idx > 0) { const key = item.slice(0, idx).trim(); try { out[key] = decodeURIComponent(item.slice(idx + 1).trim()); } catch { /* ignore malformed cookie */ } }
    }
    return out;
  }
  private sign(value: string) { return createHmac('sha256', this.authSecret).update(value).digest('hex'); }
  private verifySigned(value: string | undefined, expectedValue?: string) {
    if (!value) return false;
    const [payload, signature] = value.split('.');
    if (!payload || !signature || (expectedValue && payload !== expectedValue)) return false;
    const expected = Buffer.from(this.sign(payload), 'hex');
    let supplied: Buffer;
    try { supplied = Buffer.from(signature, 'hex'); } catch { return false; }
    return expected.length === supplied.length && timingSafeEqual(expected, supplied);
  }
  private signed(value: string) { return `${value}.${this.sign(value)}`; }
  private setCookie(res: any, name: string, value: string, maxAge: number) {
    const options = this.cookieOptions(maxAge);
    const bits = [`${name}=${encodeURIComponent(value)}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${Math.floor(maxAge / 1000)}`];
    if (options.secure) bits.push('Secure');
    const current = res.getHeader('Set-Cookie');
    const next = [...(Array.isArray(current) ? current : current ? [String(current)] : []), bits.join('; ')];
    res.setHeader('Set-Cookie', next);
  }
  private clearCookie(res: any, name: string) {
    const bits = [`${name}=`, 'Path=/', 'HttpOnly', 'SameSite=Lax', 'Max-Age=0'];
    if (this.production) bits.push('Secure');
    const current = res.getHeader('Set-Cookie');
    res.setHeader('Set-Cookie', [...(Array.isArray(current) ? current : current ? [String(current)] : []), bits.join('; ')]);
  }
  private async createSession(userId: string, res: any) {
    const raw = randomBytes(32).toString('base64url');
    const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
    await this.prisma.session.create({ data: { userId, tokenHash: this.hash(raw), expiresAt } });
    this.setCookie(res, SESSION_COOKIE, raw, SESSION_DAYS * 24 * 60 * 60 * 1000);
  }
  async currentUser(cookieHeader?: string) {
    const raw = this.parseCookies(cookieHeader)[SESSION_COOKIE];
    if (!raw) return null;
    const session = await this.prisma.session.findUnique({ where: { tokenHash: this.hash(raw) }, include: { user: true } });
    if (!session || session.expiresAt <= new Date() || session.user.status !== 'ACTIVE') return null;
    return session.user;
  }
  async register(body: { email: string; password: string; name?: string }, res: any) {
    const email = body.email.trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(email)) throw new BadRequestException('Enter a valid email address');
    if (body.password.length < 10 || body.password.length > 128) throw new BadRequestException('Password must be between 10 and 128 characters');
    if (body.name && body.name.length > 80) throw new BadRequestException('Name is too long');
    const existing = await this.prisma.user.findUnique({ where: { email } });
    if (existing) throw new ConflictException('An account with this email already exists. Sign in and link Google from Security settings.');
    const user = await this.prisma.user.create({ data: { email, displayName: body.name?.trim() || null, passwordHash: await this.passwordHash(body.password), creditAccount: { create: {} } } });
    await this.createSession(user.id, res);
    return { id: user.id, email: user.email, displayName: user.displayName };
  }
  async login(body: { email: string; password: string }, res: any) {
    const email = body.email.trim().toLowerCase();
    const user = await this.prisma.user.findUnique({ where: { email } });
    if (!user || user.status !== 'ACTIVE' || !(await this.verifyPassword(body.password, user.passwordHash))) throw new UnauthorizedException('Email or password is incorrect');
    await this.createSession(user.id, res);
    return { id: user.id, email: user.email, displayName: user.displayName };
  }
  async logout(cookieHeader: string | undefined, res: any) {
    const raw = this.parseCookies(cookieHeader)[SESSION_COOKIE];
    if (raw) await this.prisma.session.deleteMany({ where: { tokenHash: this.hash(raw) } });
    this.clearCookie(res, SESSION_COOKIE);
    return { ok: true };
  }
  async startGoogle(res: any, mode: 'login' | 'link' = 'login') {
    const clientId = this.config.get<string>('GOOGLE_CLIENT_ID');
    const clientSecret = this.config.get<string>('GOOGLE_CLIENT_SECRET');
    if (!clientId || !clientSecret) throw new ServiceUnavailableException('Google sign-in is not configured yet');
    const state = randomBytes(24).toString('base64url');
    this.setCookie(res, STATE_COOKIE, this.signed(`${mode}:${state}`), 10 * 60 * 1000);
    const params = new URLSearchParams({ client_id: clientId, redirect_uri: `${this.apiUrl}/api/v1/auth/google/callback`, response_type: 'code', scope: 'openid email profile', state, prompt: 'select_account' });
    return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
  }
  async finishGoogle(query: { code?: string; state?: string; error?: string }, cookieHeader: string | undefined, res: any) {
    const cookies = this.parseCookies(cookieHeader);
    const stateCookie = cookies[STATE_COOKIE];
    this.clearCookie(res, STATE_COOKIE);
    if (query.error || !query.code || !query.state || !this.verifySigned(stateCookie) || !stateCookie?.startsWith(`${this.modeFromState(stateCookie)}:${query.state}.`)) {
      throw new UnauthorizedException('Google sign-in was cancelled or the security check failed');
    }
    const statePayload = stateCookie.slice(0, stateCookie.lastIndexOf('.'));
    const mode = statePayload.split(':')[0];
    const tokenResponse = await fetch('https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ code: query.code, client_id: this.config.get<string>('GOOGLE_CLIENT_ID')!, client_secret: this.config.get<string>('GOOGLE_CLIENT_SECRET')!, redirect_uri: `${this.apiUrl}/api/v1/auth/google/callback`, grant_type: 'authorization_code' }) });
    if (!tokenResponse.ok) throw new UnauthorizedException('Could not complete Google sign-in');
    const tokenData = await tokenResponse.json() as { access_token?: string };
    if (!tokenData.access_token) throw new UnauthorizedException('Google did not return an access token');
    const profileResponse = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { authorization: `Bearer ${tokenData.access_token}` } });
    if (!profileResponse.ok) throw new UnauthorizedException('Could not verify your Google account');
    const profile = await profileResponse.json() as GoogleProfile;
    if (!profile.sub || !profile.email || profile.email_verified !== true) throw new UnauthorizedException('Google must provide a verified email address');
    const email = profile.email.trim().toLowerCase();
    if (mode === 'link') {
      const user = await this.currentUser(cookieHeader);
      const linkCookie = cookies[LINK_COOKIE];
      if (!user || !this.verifyLinkIntent(linkCookie, user.id)) {
        throw new UnauthorizedException('Sign in again and confirm your password before linking Google');
      }
      if (!user || user.email.toLowerCase() !== email) throw new ConflictException('The Google account email must match your Bonir AI email.');
      const existing = await this.prisma.oAuthAccount.findUnique({ where: { provider_providerAccountId: { provider: 'google', providerAccountId: profile.sub } } });
      if (existing && existing.userId !== user.id) throw new ConflictException('This Google account is already linked to another Bonir AI account.');
      await this.prisma.oAuthAccount.upsert({ where: { provider_providerAccountId: { provider: 'google', providerAccountId: profile.sub } }, create: { provider: 'google', providerAccountId: profile.sub, userId: user.id, email }, update: { email } });
      this.clearCookie(res, LINK_COOKIE);
      return `${this.webUrl}/app/security?linked=google`;
    }
    const linked = await this.prisma.oAuthAccount.findUnique({ where: { provider_providerAccountId: { provider: 'google', providerAccountId: profile.sub } }, include: { user: true } });
    if (linked) {
      if (linked.user.status !== 'ACTIVE') throw new ForbiddenException('This account is unavailable');
      await this.createSession(linked.userId, res);
      return `${this.webUrl}/app`;
    }
    const existingUser = await this.prisma.user.findUnique({ where: { email } });
    if (existingUser) return `${this.webUrl}/login?google=link-required`;
    const user = await this.prisma.user.create({ data: { email, displayName: profile.name || null, oauthAccounts: { create: { provider: 'google', providerAccountId: profile.sub, email } }, creditAccount: { create: {} } } });
    await this.createSession(user.id, res);
    return `${this.webUrl}/app`;
  }
  private modeFromState(cookie: string) { const payload = cookie.split('.')[0] || ''; return payload.split(':')[0] || 'login'; }
  private verifyLinkIntent(value: string | undefined, userId?: string) {
    if (!value || !userId) return false;
    const payload = value.slice(0, value.lastIndexOf('.'));
    if (!this.verifySigned(value) || !payload.startsWith(`${userId}:`)) return false;
    const ts = Number(payload.slice(userId.length + 1));
    return Number.isFinite(ts) && Math.floor(Date.now() / 1000) - ts >= 0 && Math.floor(Date.now() / 1000) - ts <= 600;
  }
  async prepareGoogleLink(cookieHeader: string | undefined, body: { password: string }, res: any) {
    const user = await this.currentUser(cookieHeader);
    if (!user) throw new UnauthorizedException('Sign in to your existing account first');
    if (!(await this.verifyPassword(body.password, user.passwordHash))) throw new UnauthorizedException('Password is incorrect');
    const ts = Math.floor(Date.now() / 1000);
    this.setCookie(res, LINK_COOKIE, this.signed(`${user.id}:${ts}`), 10 * 60 * 1000);
    const url = await this.startGoogle(res, 'link');
    return { url };
  }
  async unlinkGoogle(cookieHeader: string | undefined) {
    const user = await this.currentUser(cookieHeader);
    if (!user) throw new UnauthorizedException('Sign in first');
    if (!user.passwordHash) throw new BadRequestException('Set a password before disconnecting your only sign-in method');
    await this.prisma.oAuthAccount.deleteMany({ where: { userId: user.id, provider: 'google' } });
    return { ok: true };
  }
  async security(cookieHeader: string | undefined) {
    const user = await this.currentUser(cookieHeader);
    if (!user) throw new UnauthorizedException('Sign in first');
    const account = await this.prisma.oAuthAccount.findUnique({ where: { provider_userId: { provider: 'google', userId: user.id } } });
    return { id: user.id, email: user.email, displayName: user.displayName, hasPassword: Boolean(user.passwordHash), googleLinked: Boolean(account), googleEmail: account?.email || null };
  }
}
