import { Body, Controller, Get, Post, Query, Req, Res, UseGuards, HttpCode } from '@nestjs/common';
import { IsEmail, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
import { Request, Response } from 'express';
import { AuthService } from './auth.service';

class CredentialsDto {
  @IsEmail() @MaxLength(254) email!: string;
  @IsString() @MinLength(10) @MaxLength(128) password!: string;
}
class RegisterDto extends CredentialsDto { @IsOptional() @IsString() @MaxLength(80) name?: string; }
class LinkDto { @IsString() @MinLength(10) @MaxLength(128) password!: string; }

@Controller('auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}
  @Post('register') register(@Body() body: RegisterDto, @Res({ passthrough: true }) res: Response) { return this.auth.register(body, res); }
  @Post('login') @HttpCode(200) login(@Body() body: CredentialsDto, @Res({ passthrough: true }) res: Response) { return this.auth.login(body, res); }
  @Post('logout') @HttpCode(200) logout(@Req() req: Request, @Res({ passthrough: true }) res: Response) { return this.auth.logout(req.headers.cookie, res); }
  @Get('me') async me(@Req() req: Request) { const user = await this.auth.currentUser(req.headers.cookie); return user ? { id: user.id, email: user.email, displayName: user.displayName } : null; }
  @Get('security') security(@Req() req: Request) { return this.auth.security(req.headers.cookie); }
  @Get('google') async google(@Res() res: Response) { const url = await this.auth.startGoogle(res, 'login'); return res.redirect(url); }
  @Get('google/callback') async googleCallback(@Query() query: { code?: string; state?: string; error?: string }, @Req() req: Request, @Res() res: Response) {
    try { return res.redirect(await this.auth.finishGoogle(query, req.headers.cookie, res)); }
    catch (error) { const message = error instanceof Error ? error.message : 'Google sign-in failed'; return res.redirect(`${process.env.WEB_URL || 'http://localhost:3000'}/login?google=error&reason=${encodeURIComponent(message.slice(0, 140))}`); }
  }
  @Post('google/link/start') @HttpCode(200) async startLink(@Req() req: Request, @Body() body: LinkDto, @Res({ passthrough: true }) res: Response) { return this.auth.prepareGoogleLink(req.headers.cookie, body, res); }
  @Post('google/unlink') @HttpCode(200) unlink(@Req() req: Request) { return this.auth.unlinkGoogle(req.headers.cookie); }
}
