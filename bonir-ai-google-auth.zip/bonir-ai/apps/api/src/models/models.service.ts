import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class ModelsService {
  constructor(private readonly prisma: PrismaService) {}

  async listAvailable() {
    const models = await this.prisma.aIModel.findMany({
      where: { enabled: true, provider: { enabled: true } },
      select: { id: true, slug: true, name: true, description: true, type: true, capabilities: true },
      orderBy: { name: 'asc' },
    });
    return { items: models };
  }
}
