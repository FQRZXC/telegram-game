import { ModelsService } from './models.service';
import { PrismaService } from '../prisma/prisma.service';

describe('ModelsService', () => {
  it('only queries enabled models attached to enabled providers', async () => {
    const findMany = jest.fn().mockResolvedValue([]);
    const prisma = { aIModel: { findMany } } as unknown as PrismaService;
    const service = new ModelsService(prisma);

    await expect(service.listAvailable()).resolves.toEqual({ items: [] });
    expect(findMany).toHaveBeenCalledWith({
      where: { enabled: true, provider: { enabled: true } },
      select: {
        id: true, slug: true, name: true, description: true,
        type: true, capabilities: true,
      },
      orderBy: { name: 'asc' },
    });
  });
});
