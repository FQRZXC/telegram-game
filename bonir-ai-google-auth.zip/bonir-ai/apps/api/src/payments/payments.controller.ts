import { Controller, Post, ServiceUnavailableException } from '@nestjs/common';

@Controller('payments')
export class PaymentsController {
  @Post('checkout')
  checkout() {
    throw new ServiceUnavailableException({
      code: 'PAYMENT_PROVIDER_NOT_CONFIGURED',
      message: 'Checkout is unavailable until a real payment provider is configured.',
    });
  }
}
