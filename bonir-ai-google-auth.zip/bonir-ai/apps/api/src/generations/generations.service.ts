import { Injectable, ServiceUnavailableException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class GenerationsService {
  constructor(private readonly config: ConfigService) {}

  create(): never {
    const provider = this.config.get<string>('AI_PROVIDER');
    const baseUrl = this.config.get<string>('AI_API_BASE_URL');
    const apiKey = this.config.get<string>('AI_API_KEY');

    if (!provider || !baseUrl || !apiKey) {
      throw new ServiceUnavailableException({
        code: 'AI_PROVIDER_NOT_CONFIGURED',
        message: 'AI generation is not configured yet.',
      });
    }

    throw new ServiceUnavailableException({
      code: 'AI_ADAPTER_NOT_IMPLEMENTED',
      message: 'No verified provider adapter is registered.',
    });
  }
}
