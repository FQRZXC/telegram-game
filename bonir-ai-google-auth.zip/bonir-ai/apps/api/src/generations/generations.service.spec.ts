import { ConfigService } from '@nestjs/config';
import { ServiceUnavailableException } from '@nestjs/common';
import { GenerationsService } from './generations.service';

describe('GenerationsService', () => {
  it('fails closed when no provider is configured', () => {
    const config = { get: jest.fn().mockReturnValue(undefined) } as unknown as ConfigService;
    const service = new GenerationsService(config);

    try {
      service.create();
      fail('Expected generation to be unavailable');
    } catch (error) {
      expect(error).toBeInstanceOf(ServiceUnavailableException);
      expect((error as ServiceUnavailableException).getResponse()).toMatchObject({
        code: 'AI_PROVIDER_NOT_CONFIGURED',
      });
    }
  });

  it('does not treat configured credentials as a working adapter', () => {
    const values: Record<string, string> = {
      AI_PROVIDER: 'not-a-real-adapter',
      AI_API_BASE_URL: 'https://provider.example/api',
      AI_API_KEY: 'test-placeholder',
    };
    const config = { get: (key: string) => values[key] } as unknown as ConfigService;
    const service = new GenerationsService(config);
    expect(() => service.create()).toThrow(ServiceUnavailableException);
  });
});
