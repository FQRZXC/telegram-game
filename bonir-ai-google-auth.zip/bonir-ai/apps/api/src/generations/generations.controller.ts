import { Controller, Post } from '@nestjs/common';
import { GenerationsService } from './generations.service';

@Controller('generations')
export class GenerationsController {
  constructor(private readonly generations: GenerationsService) {}

  @Post()
  create() {
    return this.generations.create();
  }
}
