import { Controller, Get, UnauthorizedException } from '@nestjs/common';

@Controller('credits')
export class CreditsController {
  @Get('balance')
  balance() {
    // No authentication implementation yet: never expose or invent a balance.
    throw new UnauthorizedException({
      code: 'AUTHENTICATION_REQUIRED',
      message: 'Sign-in is required to access credit balance.',
    });
  }
}
