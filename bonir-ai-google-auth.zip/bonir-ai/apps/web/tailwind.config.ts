import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        ink: '#080912',
        panel: '#111321',
        line: '#25283a',
        muted: '#a4a8bf',
        violet: '#9b7bff',
        cyan: '#64d9ff'
      },
      boxShadow: {
        glow: '0 0 80px rgba(133, 93, 255, 0.16)'
      }
    },
  },
  plugins: [],
};
export default config;
