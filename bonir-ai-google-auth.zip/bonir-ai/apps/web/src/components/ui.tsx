import type { ReactNode } from 'react';

export function Eyebrow({ children }: { children: ReactNode }) {
  return <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-violet-300/20 bg-violet-300/[.07] px-3 py-1.5 text-xs font-medium text-violet-200">{children}</div>;
}
export function SectionTitle({ eyebrow, title, description }: { eyebrow?: string; title: string; description?: string }) {
  return <div className="mb-7">{eyebrow && <div className="mb-2 text-xs font-semibold uppercase tracking-[.2em] text-violet-300">{eyebrow}</div>}<h1 className="text-3xl font-semibold tracking-tight md:text-4xl">{title}</h1>{description && <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-400 md:text-base">{description}</p>}</div>;
}
export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`glass rounded-2xl p-5 md:p-6 ${className}`}>{children}</section>;
}
export function Badge({ children }: { children: ReactNode }) {
  return <span className="rounded-full border border-white/10 bg-white/[.04] px-2.5 py-1 text-xs text-slate-300">{children}</span>;
}
