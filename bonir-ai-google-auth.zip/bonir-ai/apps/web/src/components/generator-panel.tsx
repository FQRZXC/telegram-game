'use client';

import { useState } from 'react';
import { AlertCircle, Image as ImageIcon, Video, WandSparkles } from 'lucide-react';

const apiBase = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:4000/api/v1';

export function GeneratorPanel({ kind }: { kind: 'video' | 'image' }) {
  const [prompt, setPrompt] = useState('');
  const [model, setModel] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [errorCode, setErrorCode] = useState('');

  async function submit() {
    setBusy(true); setNotice(''); setErrorCode('');
    try {
      const response = await fetch(`${apiBase}/generations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: kind === 'video' ? 'TEXT_TO_VIDEO' : 'TEXT_TO_IMAGE', prompt, model }),
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        setErrorCode(payload.code || 'GENERATION_UNAVAILABLE');
        setNotice(payload.message || 'Generation is not available until a real provider is configured.');
      } else {
        setNotice('Request accepted.');
      }
    } catch {
      setErrorCode('API_UNREACHABLE');
      setNotice('Cannot connect to the Bonir API. Start the backend and try again.');
    } finally {
      setBusy(false);
    }
  }

  const Icon = kind === 'video' ? Video : ImageIcon;
  return (
    <div className="grid gap-5 xl:grid-cols-[minmax(0,1.1fr)_minmax(280px,.9fr)]">
      <section className="glass rounded-3xl p-5 md:p-7">
        <div className="mb-6 flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-violet-400/10 text-violet-200"><Icon size={21}/></div><div><h2 className="font-semibold">Create {kind}</h2><p className="mt-1 text-xs text-slate-400">Provider-backed generation only</p></div></div>
        <label className="mb-2 block text-sm font-medium">Prompt</label>
        <textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={6} maxLength={4000} placeholder={kind === 'video' ? 'Describe the scene, camera movement, lighting, mood…' : 'Describe the subject, style, composition, lighting…'} className="field w-full resize-y p-4 text-sm leading-6" />
        <div className="mt-2 flex justify-between text-xs text-slate-500"><span>Be specific about style and composition.</span><span>{prompt.length}/4000</span></div>
        <label className="mb-2 mt-5 block text-sm font-medium">Model ID</label>
        <input value={model} onChange={e => setModel(e.target.value)} placeholder="Select a model after an API provider is configured" className="field w-full px-4 py-3 text-sm" />
        <button disabled={busy || prompt.trim().length < 3} onClick={submit} className="btn-primary mt-5 flex w-full items-center justify-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold disabled:cursor-not-allowed disabled:opacity-50">
          <WandSparkles size={17}/>{busy ? 'Checking provider…' : 'Generate'}
        </button>
        {notice && <div role="status" className="mt-4 flex gap-2 rounded-xl border border-amber-300/20 bg-amber-300/[.06] p-3 text-sm text-amber-100"><AlertCircle size={18} className="mt-0.5 shrink-0"/><div><div>{notice}</div>{errorCode && <div className="mt-1 font-mono text-xs text-amber-200/70">{errorCode}</div>}</div></div>}
      </section>
      <section className="glass flex min-h-[360px] flex-col items-center justify-center rounded-3xl p-6 text-center">
        <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-3xl border border-white/10 bg-white/[.03] text-slate-500"><Icon size={32}/></div>
        <h3 className="font-semibold">Your result appears here</h3>
        <p className="mt-2 max-w-xs text-sm leading-6 text-slate-400">No preview is fabricated. Connect and verify a real provider to generate and display output.</p>
        <div className="mt-5 rounded-full border border-white/10 px-3 py-1.5 text-xs text-slate-400">Provider status: not configured</div>
      </section>
    </div>
  );
}
