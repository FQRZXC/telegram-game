import Link from 'next/link';
import { Sparkles, WandSparkles, Image as ImageIcon, Video, Layers3, CircleHelp, LayoutDashboard, CreditCard, ShieldCheck, Settings2 } from 'lucide-react';

const mainLinks = [
  { href: '/studio', label: 'AI Studio', icon: WandSparkles },
  { href: '/video', label: 'AI Video', icon: Video },
  { href: '/image', label: 'AI Image', icon: ImageIcon },
  { href: '/models', label: 'Models', icon: Layers3 },
  { href: '/pricing', label: 'Pricing', icon: CreditCard },
];

export function SiteShell({ children, wide = false, cinematic = false }: { children: React.ReactNode; wide?: boolean; cinematic?: boolean }) {
  return (
    <div className="shell">
      <header className={`sticky top-0 z-30 border-b border-white/[.07] ${cinematic ? 'bg-[#080a12]/65' : 'bg-[#080912]/80'} backdrop-blur-2xl`}>
        <div className="mx-auto flex max-w-[1500px] items-center justify-between gap-5 px-5 py-4 lg:px-8">
          <Link href="/" className="flex items-center gap-2.5 font-semibold tracking-tight">
            <span className="flex h-9 w-9 items-center justify-center rounded-[13px] border border-white/15 bg-[linear-gradient(145deg,#d6ffb7,#9c83ff_62%,#292344)] text-[#11121a] shadow-[0_0_32px_rgba(176,255,169,.12)]"><Sparkles size={19}/></span>
            <span className="text-lg">Bonir <span className="text-violet-300">AI</span></span>
          </Link>
          <nav className="hidden items-center gap-6 text-sm text-muted md:flex">
            <Link href="/models" className="hover:text-white">Models</Link>
            <Link href="/pricing" className="hover:text-white">Pricing</Link>
            <Link href="/help" className="hover:text-white">Help center</Link>
          </nav>
          <div className="flex items-center gap-2">
            <Link href="/login" className="rounded-xl px-4 py-2 text-sm text-slate-200 hover:bg-white/5">Sign in</Link>
            <Link href="/register" className="btn-primary rounded-xl px-4 py-2 text-sm font-semibold">Get started</Link>
          </div>
        </div>
      </header>
      <div className={`mx-auto flex max-w-[1500px] ${wide ? 'px-4 lg:px-6' : 'px-5 lg:px-8'}`}>
        {!cinematic && <aside className="sticky top-[73px] hidden h-[calc(100vh-73px)] w-[218px] shrink-0 flex-col border-r border-white/10 py-7 pr-5 lg:flex">
          <div className="mb-3 px-3 text-[11px] font-bold uppercase tracking-[.18em] text-slate-500">Workspace</div>
          {mainLinks.map(({ href, label, icon: Icon }) => (
            <Link key={href} href={href} className="mb-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-slate-300 transition hover:bg-white/[.06] hover:text-white">
              <Icon size={17} className="text-slate-400"/>{label}
            </Link>
          ))}
          <div className="mb-3 mt-8 px-3 text-[11px] font-bold uppercase tracking-[.18em] text-slate-500">Account</div>
          <Link href="/app" className="mb-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-slate-300 hover:bg-white/[.06]"><LayoutDashboard size={17}/>Dashboard</Link>
          <Link href="/app/billing" className="mb-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-slate-300 hover:bg-white/[.06]"><CreditCard size={17}/>Billing</Link>
          <Link href="/app/security" className="mb-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-slate-300 hover:bg-white/[.06]"><Settings2 size={17}/>Security</Link>
          <Link href="/help" className="mb-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-slate-300 hover:bg-white/[.06]"><CircleHelp size={17}/>Support</Link>
          <div className="mt-auto rounded-2xl border border-violet-400/20 bg-violet-400/[.07] p-4">
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold"><ShieldCheck size={16} className="text-violet-300"/>Private by design</div>
            <p className="text-xs leading-5 text-slate-400">Your workspace will keep generations and files linked to your account.</p>
          </div>
        </aside>}
        <main className={`min-w-0 flex-1 ${cinematic ? 'py-0' : 'py-7 lg:pl-7'}`}>{children}</main>
      </div>
      <footer className="border-t border-white/10 px-5 py-8 text-xs text-slate-500">
        <div className="mx-auto flex max-w-[1400px] flex-wrap items-center justify-between gap-3">
          <span>© {new Date().getFullYear()} Bonir AI</span>
          <div className="flex gap-5"><Link href="/terms">Terms</Link><Link href="/privacy">Privacy</Link><Link href="/help">Support</Link></div>
        </div>
      </footer>
    </div>
  );
}
