import Link from 'next/link';
import { Layers3, ArrowUpRight, CircleHelp } from 'lucide-react';
import { SiteShell } from '@/components/site-shell';
import { Card, SectionTitle } from '@/components/ui';

const apiBase = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:4000/api/v1';

async function getModels() {
  try {
    const res = await fetch(`${apiBase}/models`, { cache: 'no-store' });
    if (!res.ok) return null;
    return await res.json();
  } catch { return null; }
}

export default async function ModelsPage() {
  const data = await getModels();
  const items = data?.items ?? [];
  return <SiteShell><SectionTitle eyebrow="Catalogue" title="Explore AI models" description="Only models enabled in the Bonir backend and attached to an enabled provider appear here."/>
    {items.length ? <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{items.map((m: {id:string; name:string; slug:string; type:string; description?:string}) => <Card key={m.id}><div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-violet-400/10 text-violet-200"><Layers3 size={20}/></div><h2 className="font-semibold">{m.name}</h2><p className="mt-2 text-xs text-slate-400">{m.type.replaceAll('_',' ')}</p><p className="mt-3 text-sm text-slate-400">{m.description || 'Provider model'}</p><div className="mt-5 font-mono text-xs text-slate-500">{m.slug}</div></Card>)}</div> :
    <Card className="flex min-h-[300px] flex-col items-center justify-center text-center"><div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-white/[.04] text-slate-400"><Layers3 size={25}/></div><h2 className="text-lg font-semibold">No models are available yet</h2><p className="mt-2 max-w-md text-sm leading-6 text-slate-400">{data === null ? 'The API is unreachable. Start the backend and database to load the live catalogue.' : 'No verified providers have been enabled. Add a real provider adapter before publishing models.'}</p><Link href="/help" className="mt-5 inline-flex items-center gap-2 text-sm text-violet-200">Setup guide <ArrowUpRight size={15}/></Link></Card>}
  </SiteShell>;
}
