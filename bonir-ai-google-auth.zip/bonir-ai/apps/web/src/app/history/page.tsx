import { History, Search } from 'lucide-react';
import { SiteShell } from '@/components/site-shell';
import { Card, SectionTitle } from '@/components/ui';

export default function HistoryPage() {
  return <SiteShell><SectionTitle eyebrow="Library" title="Generation history" description="Review previous jobs, statuses, and results associated with your account."/><Card><div className="flex items-center gap-3 rounded-xl border border-white/10 bg-black/20 px-4 py-3"><Search size={17} className="text-slate-500"/><span className="text-sm text-slate-500">Search history will be available after authentication</span></div><div className="flex min-h-[260px] flex-col items-center justify-center text-center"><History size={28} className="text-slate-500"/><h2 className="mt-4 font-semibold">No history loaded</h2><p className="mt-2 max-w-sm text-sm leading-6 text-slate-400">This page does not fabricate jobs. Sign in and connect a real provider to populate history.</p></div></Card></SiteShell>;
}
