'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { ArrowUpRight, Fingerprint, LockKeyhole, Sparkles, LoaderCircle } from 'lucide-react';
import { SiteShell } from '@/components/site-shell';

const API = (process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1').replace(/\/$/, '');

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const google = params.get('google');
    if (google === 'link-required') setError('An account with this email already exists. Sign in with your password, then open Security to connect Google.');
    else if (google === 'error') setError(params.get('reason') || 'Google sign-in failed. Please try again.');
  }, []);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError('');
    try {
      const response = await fetch(`${API}/auth/login`, { method: 'POST', credentials: 'include', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || 'Could not sign in');
      window.location.assign('/app');
    } catch (e) { setError(e instanceof Error ? e.message : 'Network error. Check that the API is running.'); }
    finally { setBusy(false); }
  }

  return <SiteShell cinematic><div className="editorial-page"><div className="mb-10 max-w-3xl"><div className="section-index"><span>ACCOUNT / 01</span> · YOUR SPACE IS WAITING</div><h1 className="editorial-heading mt-6">Welcome<br/><em>back to wonder.</em></h1><p className="editorial-lede">Step back into your creative universe. Your next idea is closer than it looks.</p></div><div className="grid gap-8 md:grid-cols-[1fr_.85fr]"><div className="editorial-panel p-6 md:p-9"><div className="mb-7 flex items-center gap-3"><span className="grid h-11 w-11 place-items-center rounded-full border border-white/15 text-[#d4ff9c]"><Fingerprint size={21}/></span><div><h2 className="text-lg font-semibold">Sign in to Bonir AI</h2><p className="mt-1 text-xs text-white/40">Your tools. Your history. Your world.</p></div></div>
      <a href={`${API}/auth/google`} className="flex w-full items-center justify-center gap-3 border border-white/15 bg-white/[.06] px-5 py-3.5 text-sm font-semibold transition hover:border-white/30 hover:bg-white/[.1]"><GoogleMark/>Continue with Google</a>
      <div className="my-6 flex items-center gap-3 text-[10px] uppercase tracking-[.2em] text-white/35"><span className="h-px flex-1 bg-white/10"/>or with email<span className="h-px flex-1 bg-white/10"/></div>
      <form onSubmit={submit}><label className="editorial-label mb-2 block" htmlFor="email">Email address</label><input id="email" required autoComplete="email" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" className="field w-full rounded-none px-4 py-3"/><label className="editorial-label mb-2 mt-5 block" htmlFor="password">Password</label><input id="password" required autoComplete="current-password" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Your password" className="field w-full rounded-none px-4 py-3"/>
      {error && <p role="alert" className="mt-4 border border-rose-300/20 bg-rose-300/[.06] p-3 text-sm leading-5 text-rose-100">{error}</p>}
      <button disabled={busy} className="mt-6 flex w-full items-center justify-between border border-[#d4ff9c]/30 bg-[#d4ff9c] px-5 py-4 text-left text-sm font-semibold text-[#151812] transition hover:bg-[#e1ffbd] disabled:opacity-60"><span>{busy ? 'Signing in…' : 'Sign in securely'}</span>{busy ? <LoaderCircle size={16} className="animate-spin"/> : <LockKeyhole size={16}/>}</button></form>
      <p className="mt-5 text-center text-sm text-white/50">New around here? <Link href="/register" className="text-[#d4ff9c] underline underline-offset-4">Create an account <ArrowUpRight size={13} className="inline"/></Link></p></div><div className="relative flex min-h-[320px] flex-col justify-between overflow-hidden border border-white/10 bg-[#17182a] p-7"><div className="login-moon"/><div className="relative z-10"><div className="editorial-label">A NOTE FROM THE FUTURE</div><p className="mt-7 max-w-sm text-3xl leading-tight tracking-[-.055em]">“You don’t have to know what you’re making <em className="font-serif text-[#d4ff9c]">before you begin.</em>”</p></div><div className="relative z-10 flex items-center justify-between border-t border-white/15 pt-4 text-[10px] tracking-[.15em] text-white/40"><span>BONIR CREATIVE SYSTEM</span><span>© 2026</span></div></div></div></div></SiteShell>;
}

function GoogleMark() { return <svg aria-hidden="true" width="18" height="18" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5Z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.76 7.18l7.73 6C44.42 38.04 46.98 31.89 46.98 24.55Z"/><path fill="#FBBC05" d="M10.53 28.59A14.4 14.4 0 0 1 9.75 24c0-1.59.27-3.13.76-4.59l-7.98-6.19A23.9 23.9 0 0 0 0 24c0 3.87.93 7.52 2.56 10.78l7.97-6.19Z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.91-5.8l-7.73-6c-2.14 1.44-4.89 2.3-8.18 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48Z"/></svg>; }
