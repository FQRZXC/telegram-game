import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Bonir AI — Create beyond imagination',
  description: 'AI creation studio for images, video, and creative workflows.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
