import { SiteShell } from '@/components/site-shell';
import { SectionTitle } from '@/components/ui';
import { GeneratorPanel } from '@/components/generator-panel';

export default function ImagePage() {
  return <SiteShell><SectionTitle eyebrow="Create" title="AI Image" description="Use this workspace for image-generation workflows once a real image provider is connected."/><GeneratorPanel kind="image"/></SiteShell>;
}
