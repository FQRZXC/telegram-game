import Link from 'next/link';
import { ArrowDownRight, ArrowRight, AudioLines, CirclePlay, Image as ImageIcon, MoveUpRight, Orbit, Sparkles, Video, WandSparkles } from 'lucide-react';
import { SiteShell } from '@/components/site-shell';

const features = [
  { n: '01', icon: Video, title: 'Give ideas motion.', desc: 'Turn a feeling, a frame, or a sentence into moving worlds.', href: '/video', tag: 'MOTION LAB' },
  { n: '02', icon: ImageIcon, title: 'Make the unreal tangible.', desc: 'Explore visual directions, compositions, and new aesthetics.', href: '/image', tag: 'IMAGE ENGINE' },
  { n: '03', icon: Orbit, title: 'Find your model.', desc: 'A growing map of creative systems, collected in one place.', href: '/models', tag: 'MODEL UNIVERSE' },
];

function LivingCity() {
  return <div className="living-city" aria-hidden="true">
    <div className="city-sun"/><div className="city-haze haze-one"/><div className="city-haze haze-two"/>
    <div className="city-moon"><span/></div>
    <div className="city-stars">{Array.from({length:38},(_,i)=><i key={i} style={{left:`${(i*37+7)%100}%`,top:`${(i*19+8)%52}%`,animationDelay:`${(i%9)*-.7}s`,opacity:.25+(i%5)*.12}}/>)}</div>
    <div className="city-skyline skyline-back">{Array.from({length:18},(_,i)=><div key={i} className="building" style={{height:`${25+(i*31)%54}%`,width:`${3+(i%3)}%`,left:`${i*5.7-1}%`,animationDelay:`${(i%7)*-.8}s`}}><span className="windows">{Array.from({length:12},(_,j)=><i key={j} style={{animationDelay:`${((i+j)%8)*-.65}s`}}/>)}</span></div>)}</div>
    <div className="city-skyline skyline-front">{Array.from({length:12},(_,i)=><div key={i} className="building" style={{height:`${20+(i*23)%46}%`,width:`${5+(i%2)*2}%`,left:`${i*8.5-2}%`,animationDelay:`${(i%6)*-.9}s`}}><span className="windows">{Array.from({length:15},(_,j)=><i key={j} style={{animationDelay:`${((i*3+j)%10)*-.55}s`}}/>)}</span></div>)}</div>
    <div className="city-road"><div className="road-glow"/></div>
    <div className="floating-leaf leaf-a">✦</div><div className="floating-leaf leaf-b">✳</div><div className="floating-leaf leaf-c">✦</div><div className="floating-leaf leaf-d">✳</div>
    <div className="city-grain"/>
  </div>;
}

export default function HomePage() {
  return <SiteShell wide cinematic>
    <section className="home-hero relative isolate overflow-hidden">
      <LivingCity />
      <div className="hero-grid-lines" aria-hidden="true"/>
      <div className="hero-content relative z-10 mx-auto grid max-w-[1420px] items-end gap-12 px-5 pb-20 pt-16 md:px-10 md:pb-28 md:pt-24 lg:grid-cols-[1.05fr_.95fr] lg:gap-16">
        <div className="max-w-3xl">
          <div className="hero-kicker"><span className="live-dot"/> A CREATIVE MACHINE FOR WHAT'S NEXT <span className="kicker-year">EST. IN THE FUTURE</span></div>
          <h1 className="hero-title mt-7">Reality is just<br/> <em>the first draft.</em></h1>
          <p className="hero-copy mt-7 max-w-xl">A new space for making things that do not exist yet. Images, motion, strange little worlds — shaped with AI, guided by you.</p>
          <div className="mt-9 flex flex-wrap items-center gap-3">
            <Link href="/studio" className="hero-cta"><span>Enter the studio</span><MoveUpRight size={17}/></Link>
            <Link href="/models" className="hero-secondary"><CirclePlay size={16}/> Explore the models</Link>
          </div>
          <div className="hero-meta mt-10"><span><i/> Image experiments</span><b>·</b><span><i/> Cinematic motion</span><b>·</b><span><i/> One open canvas</span></div>
        </div>
        <div className="hero-orbit-wrap relative mx-auto w-full max-w-[520px] lg:mb-2">
          <div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="orbit-core"><div className="core-inner"><Sparkles size={27}/><span>MAKE<br/>BELIEVE</span></div></div>
          <div className="orbit-label label-top"><span className="label-index">A / 01</span><span>IMAGINATION ENGINE</span></div>
          <div className="orbit-label label-left"><span className="tiny-pulse"/> INPUT <strong>your idea</strong></div>
          <div className="orbit-label label-right"><span className="tiny-pulse purple"/> OUTPUT <strong>new reality</strong></div>
          <div className="orbit-label label-bottom"><span>INFINITE DIRECTIONS</span><ArrowDownRight size={15}/></div>
          <div className="orbit-satellite satellite-one"><WandSparkles size={17}/></div><div className="orbit-satellite satellite-two"><AudioLines size={17}/></div><div className="orbit-satellite satellite-three"><Video size={17}/></div>
        </div>
      </div>
      <div className="hero-bottomline relative z-10 mx-5 md:mx-10"><span>NO FIXED AESTHETIC. NO FINISH LINE.</span><span>SCROLL TO EXPLORE <ArrowDownRight size={14}/></span></div>
    </section>

    <section className="manifesto-section px-5 py-20 md:px-10 md:py-28">
      <div className="mx-auto grid max-w-[1320px] gap-10 md:grid-cols-[.75fr_1.25fr] md:gap-20">
        <div><div className="section-index"><span>01</span> / THE NEW CREATIVE ERA</div><div className="manifesto-stamp mt-8">MAKE<br/><em>WEIRD.</em><br/>MAKE<br/>WONDER.</div></div>
        <div className="self-end"><p className="manifesto-copy">The future never arrives in one style. It is a little bit <em>space-age optimism</em>, a little bit internet-after-dark, and entirely yours to bend.</p><p className="mt-6 max-w-xl text-sm leading-7 text-white/50">Bonir AI brings creative tools into one fluid workspace — less dashboard, more playground. Start with a thought. Follow it somewhere unexpected.</p><Link href="/studio" className="text-link mt-8 inline-flex items-center gap-2">Make something unexpected <ArrowRight size={15}/></Link></div>
      </div>
    </section>

    <section className="feature-section px-5 pb-20 md:px-10 md:pb-28">
      <div className="mx-auto max-w-[1320px]"><div className="mb-9 flex flex-wrap items-end justify-between gap-4"><div><div className="section-index"><span>02</span> / YOUR TOOLBOX FOR THE IMPOSSIBLE</div><h2 className="section-heading mt-5">Different tools.<br/><em>One strange universe.</em></h2></div><Link href="/models" className="text-link mb-2 inline-flex items-center gap-2">See all models <ArrowRight size={15}/></Link></div>
      <div className="feature-grid">{features.map(({n,icon:Icon,title,desc,href,tag})=><Link href={href} key={n} className="feature-tile group"><div className="feature-tile-top"><span>{n} / {tag}</span><MoveUpRight size={17}/></div><div className="feature-icon"><Icon size={23}/></div><h3>{title}</h3><p>{desc}</p><div className="tile-bottom"><span>EXPLORE TOOL</span><span className="tile-arrow"><ArrowRight size={15}/></span></div></Link>)}</div>
      </div>
    </section>

    <section className="closing-section mx-5 mb-16 overflow-hidden md:mx-10 md:mb-24"><div className="closing-asterisk">✳</div><div className="relative z-10"><div className="section-index"><span>03</span> / THE CANVAS IS YOURS</div><h2>Ideas do not<br/><em>sit still.</em></h2><p>Give yours somewhere to go.</p><Link href="/studio" className="hero-cta mt-7 inline-flex"><span>Start creating</span><MoveUpRight size={17}/></Link></div><div className="closing-orbit"/><div className="closing-orbit closing-orbit-two"/></section>
  </SiteShell>;
}
