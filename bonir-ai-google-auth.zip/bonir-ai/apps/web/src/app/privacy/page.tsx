import { SiteShell } from '@/components/site-shell';
import { Card, SectionTitle } from '@/components/ui';

export default function PrivacyPage() {
  return <SiteShell><SectionTitle eyebrow="Legal" title="Privacy policy" description="Draft placeholder — complete this with the actual data flows, jurisdiction, processors, and retention periods before launch."/><Card><h2 className="font-semibold">Data minimization</h2><p className="mt-2 text-sm leading-6 text-slate-400">The production service should collect only the information needed to provide accounts, process generation jobs, protect the platform, and meet legal obligations.</p><h2 className="mt-6 font-semibold">Uploaded files and generated media</h2><p className="mt-2 text-sm leading-6 text-slate-400">Production storage must be private by default, enforce ownership checks, use expiring signed URLs, and document retention and deletion behavior.</p><h2 className="mt-6 font-semibold">Third-party providers</h2><p className="mt-2 text-sm leading-6 text-slate-400">Disclose which AI, hosting, analytics, email, and payment processors receive data, and link to their applicable policies.</p></Card></SiteShell>;
}
