import { SiteShell } from '@/components/site-shell';
import { SectionTitle } from '@/components/ui';
import { GeneratorPanel } from '@/components/generator-panel';

export default function StudioPage() {
  return <SiteShell><SectionTitle eyebrow="Workspace" title="AI Studio" description="Choose a creative workflow, write your prompt, and connect a verified provider to generate real results."/><div className="mb-5 flex flex-wrap gap-2 text-xs text-slate-400"><span className="rounded-full border border-white/10 px-3 py-1.5">Text to video</span><span className="rounded-full border border-white/10 px-3 py-1.5">Text to image</span><span className="rounded-full border border-white/10 px-3 py-1.5">Reference input · coming with adapter</span></div><GeneratorPanel kind="image"/></SiteShell>;
}
