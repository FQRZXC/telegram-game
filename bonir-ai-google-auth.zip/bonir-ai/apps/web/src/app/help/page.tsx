import { BookOpen, CircleHelp, ExternalLink, ShieldCheck } from 'lucide-react';
import { SiteShell } from '@/components/site-shell';
import { Card, SectionTitle } from '@/components/ui';

const items = [
  ['How do I enable generation?', 'Choose a provider with an official API, implement and test its adapter, configure server-side credentials, and explicitly enable supported models in the database.'],
  ['Why is payment disabled?', 'No payment provider is configured. Checkout must remain unavailable until signed webhooks, idempotency, refunds, and reconciliation are implemented.'],
  ['Are my API keys safe?', 'Keep keys only in the backend environment or secret manager. Never add them to NEXT_PUBLIC variables or frontend source code.'],
  ['Can I deploy this now?', 'Use it locally to review the design and architecture. Complete authentication, authorization, financial invariants, storage controls, monitoring, backups, and security review before public launch.'],
];

export default function HelpPage() {
  return <SiteShell><SectionTitle eyebrow="Help center" title="How can we help?" description="Setup notes for the Bonir AI starter and the steps required to enable real production features."/><div className="grid gap-4 xl:grid-cols-[1fr_300px]"><div className="space-y-3">{items.map(([q,a])=><Card key={q}><h2 className="font-semibold">{q}</h2><p className="mt-2 text-sm leading-6 text-slate-400">{a}</p></Card>)}</div><Card><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-400/10 text-violet-200"><BookOpen size={20}/></div><h2 className="mt-4 font-semibold">Project documentation</h2><p className="mt-2 text-sm leading-6 text-slate-400">See the docs folder for architecture, security, integration, and VPS checklists.</p><div className="mt-5 flex items-center gap-2 text-xs text-slate-500"><ShieldCheck size={15}/> Security-first setup</div><div className="mt-3 flex items-center gap-2 text-xs text-slate-500"><CircleHelp size={15}/> Provider integrations pending</div></Card></div></SiteShell>;
}
