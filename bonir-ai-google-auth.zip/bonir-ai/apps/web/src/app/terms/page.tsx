import { SiteShell } from '@/components/site-shell';
import { Card, SectionTitle } from '@/components/ui';

export default function TermsPage() {
  return <SiteShell><SectionTitle eyebrow="Legal" title="Terms of service" description="Draft placeholder for review — not legal advice and not ready for publication."/><Card><h2 className="font-semibold">Service availability</h2><p className="mt-2 text-sm leading-6 text-slate-400">Bonir AI is under development. Generation, subscriptions, and payment features must not be advertised as available until the corresponding integrations are operational and tested.</p><h2 className="mt-6 font-semibold">Acceptable use</h2><p className="mt-2 text-sm leading-6 text-slate-400">Before launch, publish clear rules covering prohibited content, rights to uploaded materials, user responsibilities, and provider-specific restrictions.</p><h2 className="mt-6 font-semibold">Billing</h2><p className="mt-2 text-sm leading-6 text-slate-400">No payment is collected by this starter. A final policy must describe prices, credit expiration, refunds, taxes, and subscription cancellation.</p></Card></SiteShell>;
}
