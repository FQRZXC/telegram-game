import { SiteShell } from '@/components/site-shell';
import { SectionTitle } from '@/components/ui';
import { GeneratorPanel } from '@/components/generator-panel';

export default function VideoPage() {
  return <SiteShell><SectionTitle eyebrow="Create" title="AI Video" description="Prepare prompts for text-to-video workflows. Generation remains disabled until a real video API adapter is configured."/><GeneratorPanel kind="video"/></SiteShell>;
}
