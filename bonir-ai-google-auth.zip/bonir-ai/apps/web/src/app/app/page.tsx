import Link from 'next/link';
import { Activity, ArrowRight, Clock3, CreditCard, FolderOpen, Sparkles } from 'lucide-react';
import { SiteShell } from '@/components/site-shell';
import { Card, SectionTitle } from '@/components/ui';

const stats = [{ label: 'Available credits', value: '—', note: 'Sign in to load balance', icon: CreditCard }, { label: 'Generations', value: '—', note: 'No history loaded', icon: Activity }, { label: 'Saved assets', value: '—', note: 'Private library', icon: FolderOpen }];

export default function DashboardPage() {
  return <SiteShell><SectionTitle eyebrow="Your account" title="Dashboard" description="Your creative workspace at a glance. Account data appears after authentication is implemented."/>
    <div className="grid gap-4 md:grid-cols-3">{stats.map(({label,value,note,icon:Icon})=><Card key={label}><div className="flex items-center justify-between"><span className="text-sm text-slate-400">{label}</span><Icon size={18} className="text-violet-300"/></div><div className="mt-4 text-3xl font-semibold">{value}</div><div className="mt-2 text-xs text-slate-500">{note}</div></Card>)}</div>
    <div className="mt-5 grid gap-4 xl:grid-cols-[1.2fr_.8fr]"><Card><div className="flex items-center justify-between"><h2 className="font-semibold">Recent activity</h2><Clock3 size={17} className="text-slate-500"/></div><div className="flex min-h-[190px] flex-col items-center justify-center text-center"><div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-white/[.04] text-slate-400"><Activity size={22}/></div><p className="text-sm text-slate-300">No account activity loaded</p><p className="mt-1 text-xs text-slate-500">History will be account-specific after sign-in is ready.</p></div></Card>
    <Card><div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-violet-400/10 text-violet-200"><Sparkles size={20}/></div><h2 className="font-semibold">Start creating</h2><p className="mt-2 text-sm leading-6 text-slate-400">Explore the studio now. Real generations become available after a provider adapter is configured.</p><Link href="/studio" className="mt-5 inline-flex items-center gap-2 text-sm text-violet-200">Open studio <ArrowRight size={15}/></Link></Card></div>
  </SiteShell>;
}
