import Link from 'next/link';
import { CreditCard, ReceiptText, ShieldCheck } from 'lucide-react';
import { SiteShell } from '@/components/site-shell';
import { Card, SectionTitle } from '@/components/ui';

export default function BillingPage() {
  return <SiteShell><SectionTitle eyebrow="Account" title="Billing & credits" description="Payments and credit balances must be tied to a verified user and real provider events."/>
    <Card><div className="flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-xl bg-violet-400/10 text-violet-200"><CreditCard size={21}/></div><div><h2 className="font-semibold">Payment methods</h2><p className="mt-1 text-sm text-slate-400">No payment provider connected</p></div></div><div className="mt-5 rounded-xl border border-amber-300/20 bg-amber-300/[.05] p-4 text-sm leading-6 text-amber-100">Checkout is disabled. No money can be charged from this starter.</div></Card>
    <Card className="mt-4"><div className="flex items-center gap-3"><ReceiptText size={20} className="text-slate-400"/><h2 className="font-semibold">Transaction history</h2></div><div className="py-12 text-center text-sm text-slate-500">Sign in to access a verified transaction history.</div></Card>
    <p className="mt-4 flex items-center gap-2 text-xs text-slate-500"><ShieldCheck size={15}/> Payment confirmation must be verified server-side via signed webhooks.</p>
  </SiteShell>;
}
