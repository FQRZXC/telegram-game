import Link from 'next/link';
import { Activity, ArrowRight, CreditCard, Layers3, ShieldAlert, Users } from 'lucide-react';
import { SiteShell } from '@/components/site-shell';
import { Card, SectionTitle } from '@/components/ui';

const adminSections = [
  { title: 'Users & access', detail: 'Roles, status, account support', icon: Users },
  { title: 'Models & providers', detail: 'Verified adapters and model availability', icon: Layers3 },
  { title: 'Billing operations', detail: 'Payment events, refunds, reconciliation', icon: CreditCard },
  { title: 'System health', detail: 'Queues, errors, latency, audit events', icon: Activity },
];

export default function AdminPage() {
  return <SiteShell><SectionTitle eyebrow="Administration" title="Admin console" description="Administrative operations require server-enforced roles. This shell is visible for layout review only and does not grant admin access."/><Card className="mb-5 border-amber-300/20 bg-amber-300/[.04]"><div className="flex gap-3"><ShieldAlert className="shrink-0 text-amber-200" size={20}/><div><h2 className="font-semibold text-amber-100">Admin access is not enabled</h2><p className="mt-1 text-sm leading-6 text-slate-400">Do not expose this route as a real admin console until authentication, authorization guards, and audit logging are implemented.</p></div></div></Card><div className="grid gap-4 md:grid-cols-2">{adminSections.map(({title,detail,icon:Icon})=><Card key={title}><div className="flex items-start justify-between"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/[.04] text-violet-200"><Icon size={19}/></div><ArrowRight size={16} className="text-slate-500"/></div><h2 className="mt-4 font-semibold">{title}</h2><p className="mt-2 text-sm leading-6 text-slate-400">{detail}</p></Card>)}</div><Link href="/help" className="mt-5 inline-flex text-sm text-violet-200">Read setup notes →</Link></SiteShell>;
}
